Package content version overview: 
==============================================================================================================
Component               | Component  |  Name                                                  |Last Changed 
                        | Version #  |                                                        |in delivery #
==============================================================================================================                                                   
Delivery package        |    -       |  M3BE15_US_Out_SupplierPayment_ACHPPD_1    	      |  1 
MEC map                 |    1       |  M3BE15_US_Out_SupplierPayment_ACHPPD                  |  1 
User Guide              |    1       |  ACHPPD Supplier Payment for The US � User Guide v1    |  1
Flat File Definition    |    1       |  FlatFileDefinition_US_SupplierPayment_ACHPPD          |  1 
MBMInitiator            |    1       |  MBMInitiator                                          |  1 
XSD File                |    1       |  PBM_ACHPPD_BankTransfer_1                             |  1 
==============================================================================================================
