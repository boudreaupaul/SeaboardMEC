Package content version overview: 
============================================================================================================
Component               | Component  |  Name                                                |Last Changed 
                        | Version #  |                                                      |in delivery #
============================================================================================================                                                   
Delivery package        |    -       |  M3BE15_US_Out_BankRemittance_ACHCCD_1 	            |  1 
MEC map                 |    1       |  M3BE15_US_Out_BankRemittance_ACHCCD                 |  1 
User Guide              |    1       |  ACHCCD Direct Debiting for The US - User Guide v1   |  1
Flat file definition    |    1       |  FlatFileDefinition_US_BankRemittance_ACHCCD         |  1 
MBMInitiator            |    1       |  MBMInitiator                                        |  1 
XSD File                |    1       |  PBM_ACHCCD_DirectDebiting_1                         |  1 
============================================================================================================
