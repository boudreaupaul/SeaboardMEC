Package content version overview: 
======================================================================================================================
Component               | Component  |  Name                                                	       	|Last Changed 
                        | Version #  |                                                      	       	|in delivery #
======================================================================================================================                                                   
Delivery package        |    -       |  M3BE15_US_Out_SupplierTaxReport_1099_Misc_1 	    	   	|  1 
MEC map                 |    1       |  M3BE15_US_Out_SupplierTaxReport_1099_Misc        	   	|  1 
User Guide              |    1       |  1099-MISC Supplier Tax Report for The US - User Guide v1        |  1
Flat File Definition	|    1       |	FlatFileDefinition_US_SupplierTaxReport_1099_Misc	    	|  1
MBMInitiator            |    1       |  MBMInitiator                                                    |  1
XSD File                |    1       |  PBM_USA_1099_MISC_TaxReporting_1                                |  1
======================================================================================================================
