These tables describe when the content of this delivery package was last changed. It also
contains a reference to a Jira incident if applicable.



Package content version overview: 
==================================================================================================================
Component               | Component  |  Name                                                |Last Changed 
                        | Version #  |                                                      |in delivery #
===================================================================================================================                                                   
Delivery package        |    -       |  M3BE15_COI_Out_ABM_CustomerOrderInvoice_Credit_1    |  1 
MEC map                 |    1       |  M3BE15_COI_Out_ABM_CustomerOrderInvoice_Credit_1    |  1 
Message implementation  |            |                                                      | 
guide (MIG)             |    1       |  ABM_CustomerOrderInvoice_Credit_1_MIG_v1            |  1
                        |            |                                                      |
====================================================================================================================


Package version log
==================================================================================================================
Delivery |Publ.  | Description                                                       |Jira incident 
   #     |Date   | 
===================================================================================================================                                                   
   1     |1309xx |  Initial publication                                              |   
         |       |                                                                   |
         |       |                                                                   |
         |       |                                                                   |
====================================================================================================================