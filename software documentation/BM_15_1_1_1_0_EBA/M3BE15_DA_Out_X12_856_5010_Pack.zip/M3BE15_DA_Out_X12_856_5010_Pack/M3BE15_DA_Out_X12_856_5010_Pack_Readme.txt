These tables describe when the content of this delivery package was last changed. It also
contains a reference to a JIRA ticket if applicable.



Package content version overview: 
==================================================================================================================
Component               | Component  |  Name                                                |Last Changed 
                        | Version #  |                                                      |in delivery #
==================================================================================================================                                                   
Delivery package        |    -       |  M3BE15_DA_Out_X12_856_5010_Pack                     |  1
MEC map                 |    1       |  M3BE15_DA_Out_X12_856_5010_Pack                     |  1
Message implementation  |            |                                                      | 
guide (MIG)             |    1       |  M3BE15_DA_Out_X12_856_5010_Pack_MIG_v1              |  1
                        |            |                                                      |
====================================================================================================================


Package version log
==================================================================================================================
Delivery |Publ.     | Description                                                               |JIRA ticket 
   #     |Date      |                                                                           |
===================================================================================================================                                                   
   1     |2013-07-XX| Initial publication                                                       | 
         |          |                                                                         	| 	
         |          |                                                                           |    
         |          |                                                                           | 
====================================================================================================================